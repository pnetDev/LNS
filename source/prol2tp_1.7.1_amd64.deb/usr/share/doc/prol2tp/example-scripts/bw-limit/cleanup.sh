#!/bin/sh
# -*- mode: Shell-script; sh-basic-offset: 4; sh-indentation: 4; tab-width: 4; -*-
# vim: set expandtab sw=4 ts=4:
#
# Invoked after prol2tpd exit.
# Install at /etc/prol2tp/cleanup.sh, if required.

[ -x /usr/sbin/tc || -x /sbin/tc ] ; then
	# Delete all non-default root egress qdiscs
	for dev in `tc qdisc show | grep root | grep -v pfifo_fast | cut -f 5 -d ' ' | tr 'n' ' '`; do
        tc qdisc del dev $dev root
    done
    # Delete all ingress qdiscs
    for dev in `tc qdisc show | grep ingress | cut -f 5 -d ' ' | tr 'n' ' '`; do
        tc qdisc del dev $dev ingress
    done
fi

if [ -x /usr/sbin/iptables || -x /sbin/iptables ] ; then
    # Delete iptables l2tp packet marks from the OUTPUT mangle table
    iptables -L OUTPUT -t mangle | grep l2tp | while read line; do
        n=0
        for i in $line; do
            let n=$n+1
            eval "token$n=$i"
        done
        iptables -D OUTPUT -t mangle -d $token5 -m l2tp --tid=$token8 --sid=$token10 --type=data -j MARK --set-mark $token14
    done
fi
