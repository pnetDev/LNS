/*
 * Linux PPP/L2TP Bridge
 *
 * Version:	0.0.0
 *
 * Authors:	
 *		
 * Contributors:
 *
 * License:
 *		This program is free software; you can redistribute it and/or
 *		modify it under the terms of the GNU General Public License
 *		as published by the Free Software Foundation; either version
 *		2 of the License, or (at your option) any later version.
 *
 */

#ifndef _L2TP_AC_PPPOE_H
#define _L2TP_AC_PPPOE_H

#include <linux/types.h>
#include <linux/if.h>

struct l2tp_ac_pppoe_route {
	__u32 pppoe_session_id;
	char pppoe_if_name[IFNAMSIZ];
	__u32 l2tp_tunnel_id;
	__u32 l2tp_session_id;
	__u32 l2tp_peer_session_id;
};

/* NL interface */

enum {
	L2TP_AC_PPPOE_CMD_NOOP,
	L2TP_AC_PPPOE_CMD_ADD,
	L2TP_AC_PPPOE_CMD_DEL,
	L2TP_AC_PPPOE_CMD_GET,
	__L2TP_AC_PPPOE_CMD_MAX,
};

#define L2TP_AC_PPPOE_CMD_MAX	(__L2TP_AC_PPPOE_CMD_MAX - 1)

enum {
	L2TP_AC_PPPOE_ATTR_NONE,					/* no data */
	L2TP_AC_PPPOE_ATTR_L2TP_TUNNEL_ID,			/* u32 */
	L2TP_AC_PPPOE_ATTR_L2TP_SESSION_ID,			/* u32 */
	L2TP_AC_PPPOE_ATTR_L2TP_PEER_SESSION_ID,	/* u32 */
	L2TP_AC_PPPOE_ATTR_PPPOE_SESSION_ID,		/* u16 */
	L2TP_AC_PPPOE_ATTR_PPPOE_IFNAME,			/* string */
	__L2TP_AC_PPPOE_ATTR_MAX,
};

#define L2TP_AC_PPPOE_ATTR_MAX	(__L2TP_AC_PPPOE_ATTR_MAX - 1)

/*
 * NETLINK_GENERIC related info
 */
#define L2TP_AC_PPPOE_GENL_NAME          "l2tp_ac_pppoe"
#define L2TP_AC_PPPOE_GENL_VERSION       0x1

/* NL reply policies */
#if !defined(__KERNEL__)
#define L2TP_AC_PPPOE_CMD_GET_REPLY_POLICY \
	[L2TP_AC_PPPOE_ATTR_NONE]                  = { .type = NLA_UNSPEC, }, \
	[L2TP_AC_PPPOE_ATTR_L2TP_TUNNEL_ID]        = { .type = NLA_U32, }, \
	[L2TP_AC_PPPOE_ATTR_L2TP_SESSION_ID]       = { .type = NLA_U32, }, \
	[L2TP_AC_PPPOE_ATTR_L2TP_PEER_SESSION_ID]  = { .type = NLA_U32, }, \
	[L2TP_AC_PPPOE_ATTR_PPPOE_SESSION_ID]      = { .type = NLA_U16, }, \
	[L2TP_AC_PPPOE_ATTR_PPPOE_IFNAME]          = { .type = NLA_STRING, },
#endif

#endif /* _L2TP_AC_PPPOE_H */
