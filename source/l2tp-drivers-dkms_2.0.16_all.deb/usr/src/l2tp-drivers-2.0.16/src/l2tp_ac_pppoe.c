/*
 * Linux L2TP PPPoE Access Concentrator
 *
 * Version:	1.1.0
 *
 * Authors:	Chris Elston
 *		
 * Contributors:
 *
 * License:
 *		This program is free software; you can redistribute it and/or
 *		modify it under the terms of the GNU General Public License
 *		as published by the Free Software Foundation; either version
 *		2 of the License, or (at your option) any later version.
 *
 */

#include <linux/module.h>
#include <linux/version.h>
#include <linux/string.h>
#include <linux/list.h>

#include <linux/kernel.h>
#include <linux/spinlock.h>
#include <linux/semaphore.h>
#include <linux/errno.h>

#include <linux/hash.h>
#include <linux/file.h>
#include <linux/fs.h>
#include <asm/uaccess.h>
#include <linux/netdevice.h>
#include <linux/if_pppox.h>
#include <linux/proc_fs.h>

#include <net/genetlink.h>

#include <linux/l2tp.h>

#include <asm/byteorder.h>
#include <asm/atomic.h>

#include "l2tp_ac_pppoe.h"
#include "l2tp_core.h"

/* FIXME: temporary for debug - remove */
#include "linux/etherdevice.h"

#define L2TP_AC_PPPOE_DRV_VERSION "V1.2.0"

#if LINUX_VERSION_CODE < KERNEL_VERSION(3,7,0)
#define snd_portid snd_pid
#define portid pid
#endif

/* Developer debug code. */
#undef DEBUG

#ifdef DEBUG
	#define DEBUG_ERR 	1
	#define DEBUG_VERBOSE	1
	#define PRINTK(_type, _lvl, _fmt, args...)			\
		do {							\
			if (_type)					\
				printk(_lvl "l2tp_ac_pppoe: " _fmt, ##args);	\
		} while(0)
#else
	#define DEBUG_VERBOSE 0
	#define PRINTK(...)
#endif

struct l2tp_ac_pppoe_route_context {
	struct net_device *pppoe_netdev;
	uint16_t pppoe_session_id;
	unsigned char pppoe_haddr[ETH_ALEN];
	char pppoe_haddr_valid;	
	struct l2tp_session *l2tp_session;
	struct hlist_node p_hlist;	/* PPPoE session ID hashlist */
	struct list_head c_list;	/* Context list */
	struct rcu_head rcu;
	bool valid;
};

#define PPPOE_SES_HASH_BITS	5
#define PPPOE_SES_HASH_SIZE	(1 << PPPOE_SES_HASH_BITS)

struct l2tp_ac_pppoe_priv {
	struct class *class;
	int major_num;
	/* List of l2tp_ac_pppoe_route_context hashed by PPPoE session ID */
	struct hlist_head pppoe_hlist[PPPOE_SES_HASH_SIZE];
	/* List of all l2tp_ac_route_context */
	struct list_head ctxt_list;
	/* Lock for pppoe_hlist */
	spinlock_t list_lock;
	struct net *net;
};

struct l2tp_ac_pppoe_priv *priv;

static inline struct hlist_head *
l2tp_ac_pppoe_get_pppoe_hlist(u32 session_id)
{
	return &priv->pppoe_hlist[hash_long(session_id, PPPOE_SES_HASH_BITS)];
}

static struct l2tp_ac_pppoe_route_context *l2tp_ac_pppoe_get_ctxt_by_pppoe(u32 pppoe_session_id, struct net_device *dev)
{
	struct l2tp_ac_pppoe_route_context *ctxt = NULL;
	struct hlist_head *pppoe_hlist;
	struct hlist_node *pos;
 
	pppoe_hlist = l2tp_ac_pppoe_get_pppoe_hlist(pppoe_session_id);

	hlist_for_each_entry_rcu_compat(ctxt, pos, pppoe_hlist, p_hlist) {
		PRINTK(DEBUG_VERBOSE, KERN_DEBUG, "%s: Checking session 0x%04X\n",
			__func__, ctxt->pppoe_session_id);
		if ((ctxt->pppoe_session_id == pppoe_session_id) &&
		    (ctxt->pppoe_netdev == dev)) {
			if (!ctxt->valid)
				ctxt = NULL;
			break;
		}
		ctxt = NULL;
	}

	if (!ctxt) {
		PRINTK(DEBUG_ERR, KERN_DEBUG, "%s: PPPoE session 0x%04X "
			"not found.\n", __func__, pppoe_session_id);
	}

	return ctxt;
}

static struct l2tp_ac_pppoe_route_context *l2tp_ac_pppoe_get_ctxt_by_l2tp(struct net *net, u32 l2tp_tunnel_id, u32 l2tp_session_id)
{
	struct l2tp_ac_pppoe_route_context *ctxt = NULL;
	struct l2tp_tunnel *l_tunnel = NULL;
	struct l2tp_session *l_session = NULL;

	/* Get a pointer to the L2TP tunnel */
	l_tunnel = l2tp_tunnel_find(net, l2tp_tunnel_id);
	if (!l_tunnel) {
		PRINTK(DEBUG_ERR, KERN_DEBUG, "%s: couldn't find L2TP "
			"tunnel %u/%u.\n", __func__, l2tp_tunnel_id,
			l2tp_session_id);
		goto out;
	}

	/* Get a pointer to the L2TP session */
	l_session = l2tp_session_find(net, l_tunnel, l2tp_session_id);
	if (!l_session) {
		PRINTK(DEBUG_ERR, KERN_DEBUG, "%s: couldn't find L2TP "
			"session %u/%u.\n", __func__, l2tp_tunnel_id,
			l2tp_session_id);
		goto out;
	}

	ctxt = l2tp_session_priv(l_session);
out:
	return ctxt;
}

static void l2tp_ac_pppoe_invalidate_ctxt(struct l2tp_ac_pppoe_route_context *ctxt)
{
	unsigned long flags;

	/* Invalidate context and remove it from lists */
	spin_lock_irqsave(&priv->list_lock, flags);

	ctxt->valid = false;
	wmb();

	hlist_del_init_rcu(&ctxt->p_hlist);
	list_del_rcu(&ctxt->c_list);
	INIT_LIST_HEAD(&ctxt->c_list);

	if (ctxt->pppoe_netdev) {
		dev_put(ctxt->pppoe_netdev);
		ctxt->pppoe_netdev = NULL;
	}

	spin_unlock_irqrestore(&priv->list_lock, flags);

	return;
}

static int l2tp_ac_pppoe_del_route(struct net *net, u32 pppoe_session_id, char *ifname, u32 l2tp_tunnel_id, u32 l2tp_session_id)
{
	struct l2tp_ac_pppoe_route_context *ctxt = NULL;
	struct net_device *dev = NULL;
	int ret = 0;

	if (ifname)
		dev = dev_get_by_name(net, ifname);

	rcu_read_lock();
	if (dev) {
		ctxt = l2tp_ac_pppoe_get_ctxt_by_pppoe(pppoe_session_id, dev);
		dev_put(dev);
	}
	if (!ctxt)
		ctxt = l2tp_ac_pppoe_get_ctxt_by_l2tp(net, l2tp_tunnel_id,
		                                      l2tp_session_id);
	/* Couldn't find it */
	if (!ctxt) {
		rcu_read_unlock();
		ret = -ENOENT;
		goto out;
	}

	l2tp_ac_pppoe_invalidate_ctxt(ctxt);

	rcu_read_unlock();

	PRINTK(DEBUG_VERBOSE, KERN_DEBUG, "%s: Decreasing module refcount, now %d\n", __func__, module_refcount(THIS_MODULE));

out:
	return ret;
}

void l2tp_ac_pppoe_session_close(struct l2tp_session *l_session)
{
	struct l2tp_ac_pppoe_route_context *ctxt = l2tp_session_priv(l_session);

	l2tp_ac_pppoe_invalidate_ctxt(ctxt);

	module_put(THIS_MODULE);

	return;
}

void l2tp_ac_pppoe_recv_l2tp(struct l2tp_session *l_session, struct sk_buff *skb, int l2tp_data_len)
{
	struct l2tp_ac_pppoe_route_context *ctxt = l2tp_session_priv(l_session);
	struct net_device *dev;
	struct pppoe_hdr *ph;
	int data_len = skb->len;

	PRINTK(DEBUG_VERBOSE, KERN_DEBUG, "%s: L2TP packet received.\n",
		__func__);

	if (!ctxt->pppoe_haddr_valid) {
		PRINTK(DEBUG_VERBOSE, KERN_DEBUG, "%s: Destination ethernet "
			"address not known.\n", __func__);
		goto abort;
	}

	dev = ctxt->pppoe_netdev;
	if (!dev)
		goto abort;

	if (skb_cow_head(skb, sizeof(*ph) + dev->hard_header_len))
		goto abort;

	/* If the user data has PPP address and control fields, remove them */
	if ((skb->data[0] == 0xff) && (skb->data[1] == 0x03)) {
		if (pskb_may_pull(skb, 2)) {
			skb_pull(skb, 2);
			data_len -= 2;
		}
	}

	/* Add PPPoE header */
	__skb_push(skb, sizeof(*ph));
	skb_reset_network_header(skb);

	ph = pppoe_hdr(skb);
	ph->ver = 1;
	ph->type = 1;
	ph->code = 0;
	ph->sid = htons(ctxt->pppoe_session_id);
	ph->length = htons(data_len);

	/* SKB settings */
	skb->dev = dev;
	skb->protocol = __constant_htons(ETH_P_PPP_SES);
	skb->ip_summed = CHECKSUM_UNNECESSARY;

	/* Add Ethernet header */
	dev_hard_header(skb, dev, ETH_P_PPP_SES,
			ctxt->pppoe_haddr, NULL, data_len);

	dev_queue_xmit(skb);

	return;

abort:
	kfree_skb(skb);
	return;
}

#if defined(CONFIG_L2TP_DEBUGFS) || defined(CONFIG_L2TP_DEBUGFS_MODULE)
static void l2tp_ac_pppoe_show(struct seq_file *m, void *arg)
{
	struct l2tp_session *session = arg;
	struct l2tp_ac_pppoe_route_context *ctxt = l2tp_session_priv(session);
	
	seq_printf(m, "   interface %s\n", ctxt->pppoe_netdev->name);
	seq_printf(m, "   PPPoE session %d\n", ctxt->pppoe_session_id);
	if (ctxt->pppoe_haddr_valid)
		seq_printf(m, "   client hwaddr "
		              "%02X:%02X:%02X:%02X:%02X:%02X\n",
		           ctxt->pppoe_haddr[0], ctxt->pppoe_haddr[1],
		           ctxt->pppoe_haddr[2], ctxt->pppoe_haddr[3],
		           ctxt->pppoe_haddr[4], ctxt->pppoe_haddr[5]);
}
#endif

static int l2tp_ac_pppoe_session_create(struct net *net, u32 l2tp_tunnel_id, u32 l2tp_session_id, u32 l2tp_peer_session_id, struct l2tp_session_cfg *cfg)
{
	struct l2tp_ac_pppoe_route_context *ctxt;
	struct l2tp_tunnel *l_tunnel = NULL;
	struct l2tp_session *l_session = NULL;
	int ret = 0;

	PRINTK(DEBUG_VERBOSE, KERN_DEBUG, "%s: enter\n", __func__);

	l_tunnel = l2tp_tunnel_find(net, l2tp_tunnel_id);
	if (!l_tunnel) {
		PRINTK(DEBUG_ERR, KERN_DEBUG, "%s: couldn't find L2TP "
			"tunnel %u.\n", __func__, l2tp_tunnel_id);
		ret = -ENODEV;
		goto error;
	}
	PRINTK(DEBUG_VERBOSE, KERN_DEBUG, "%s: found L2TP tunnel %u.\n",
		__func__, l2tp_tunnel_id);

	/* Check that the session doesn't already exist */
	l_session = l2tp_session_find(net, l_tunnel, l2tp_session_id);
	if (l_session) {
		PRINTK(DEBUG_ERR, KERN_DEBUG, "%s: L2TP session %u already "
			"exists.\n", __func__, l2tp_session_id);
		ret = -EEXIST;
		goto error;
	}

	l_session = l2tp_session_create(
			sizeof(struct l2tp_ac_pppoe_route_context),
			l_tunnel, l2tp_session_id, l2tp_peer_session_id, cfg);
	if (!l_session) {
		PRINTK(DEBUG_ERR, KERN_DEBUG, "%s: couldn't create L2TP "
			"session.\n", __func__);
		ret = -ENOMEM;
		goto error;
	}
	PRINTK(DEBUG_VERBOSE, KERN_DEBUG, "%s: created L2TP session %u.\n",
		__func__, l2tp_session_id);

	ctxt = l2tp_session_priv(l_session);
	ctxt->l2tp_session = l_session;
	INIT_HLIST_NODE(&ctxt->p_hlist);
	INIT_LIST_HEAD(&ctxt->c_list);
	ctxt->valid = false;

	l_session->session_close = l2tp_ac_pppoe_session_close;
	l_session->recv_skb = l2tp_ac_pppoe_recv_l2tp;
#if defined(CONFIG_L2TP_DEBUGFS) || defined(CONFIG_L2TP_DEBUGFS_MODULE)
	l_session->show = l2tp_ac_pppoe_show;
#endif

	/* Increase module refcount */
	try_module_get(THIS_MODULE);
	PRINTK(DEBUG_VERBOSE, KERN_DEBUG, "%s: Increasing module refcount, now %d\n", __func__, module_refcount(THIS_MODULE));

	PRINTK(DEBUG_VERBOSE, KERN_DEBUG, "%s: created route context.\n",
		__func__);

error:
	return ret;
}

static int l2tp_ac_pppoe_add_route(struct net *net, u32 pppoe_session_id, u32 l2tp_tunnel_id, u32 l2tp_session_id, char *ifname)
{
	struct l2tp_ac_pppoe_route_context *ctxt;
	struct net_device *dev = NULL;
	unsigned long flags;
	int ret = 0;

	dev = dev_get_by_name(net, ifname);
	if (!dev) {
		PRINTK(DEBUG_VERBOSE, KERN_DEBUG, "%s: couldn't"
			" find struct net_device for '%s'\n",
			__func__, ifname);
		ret = -ENODEV;
		goto out;
	}

	ctxt = l2tp_ac_pppoe_get_ctxt_by_l2tp(net, l2tp_tunnel_id, l2tp_session_id);
	if (!ctxt) {
		ret = -ENODEV;
		goto error_put;
	}

	ctxt->pppoe_session_id = pppoe_session_id;
	ctxt->pppoe_netdev = dev;
	ctxt->valid = true;
	PRINTK(DEBUG_VERBOSE, KERN_DEBUG, "%s: marking context for PPPoE session %04X as valid\n", __func__, pppoe_session_id);

	/* Add context to our lists */
	spin_lock_irqsave(&priv->list_lock, flags);
	hlist_add_head_rcu(&ctxt->p_hlist,
		l2tp_ac_pppoe_get_pppoe_hlist(pppoe_session_id));
	list_add_tail_rcu(&ctxt->c_list, &priv->ctxt_list);
	spin_unlock_irqrestore(&priv->list_lock, flags);

out:
	return ret;

error_put:
	if (dev)
		dev_put(dev);
	goto out;
}

static int l2tp_ac_pppoe_l2tp_xmit(struct net_device *dev, struct sk_buff *skb)
{
	struct l2tp_ac_pppoe_route_context *ctxt = NULL;
	struct pppoe_hdr *ph = pppoe_hdr(skb);
	uint16_t pppoe_session_id = ntohs(ph->sid);
	struct ethhdr *eh;

	skb_pull(skb, sizeof(struct pppoe_hdr));

	/* Find the route context */
	rcu_read_lock();
	ctxt = l2tp_ac_pppoe_get_ctxt_by_pppoe(pppoe_session_id, dev);
	if (!ctxt) {
		rcu_read_unlock();
		goto error;		
	}

	PRINTK(DEBUG_VERBOSE, KERN_DEBUG, "%s: PPPoE session 0x%04X found.\n",
		__func__, pppoe_session_id);

	/* Store the MAC address */
	if (!ctxt->pppoe_haddr_valid) {
		eh = eth_hdr(skb);
		memcpy(ctxt->pppoe_haddr, eh->h_source, ETH_ALEN);
		ctxt->pppoe_haddr_valid = 1;
	}

	/* Pass skb to the L2TP core */
	l2tp_xmit_skb(ctxt->l2tp_session, skb, ctxt->l2tp_session->hdr_len);
	rcu_read_unlock();
	
	return NET_RX_SUCCESS;

error:
	kfree_skb(skb);
	return NET_RX_DROP;
}

static int l2tp_ac_pppoe_recv_pppoe(struct sk_buff *skb, struct net_device *dev, struct packet_type *pt, struct net_device *orig_dev)
{
	if (!(skb = skb_share_check(skb, GFP_ATOMIC)))
		goto out;

	if (!net_eq(dev_net(dev), &init_net))
		goto drop;

	if (!pskb_may_pull(skb, sizeof(struct pppoe_hdr)))
		goto drop;

	PRINTK(DEBUG_VERBOSE, KERN_DEBUG, "%s: PPPoE session packet "
		"received.\n", __func__);

	l2tp_ac_pppoe_l2tp_xmit(orig_dev, skb);

	return NET_RX_SUCCESS;

drop:
	PRINTK(DEBUG_ERR, KERN_DEBUG, "%s: PPPoE session packet dropped.\n",
		__func__);
	kfree_skb(skb);
out:
	return NET_RX_DROP;
}

static struct packet_type pppoes_ptype = {
	.type	= __constant_htons(ETH_P_PPP_SES),
	.func	= l2tp_ac_pppoe_recv_pppoe,
};

static struct genl_family l2tp_ac_pppoe_nl_family = {
	.id             = GENL_ID_GENERATE,
	.name           = L2TP_AC_PPPOE_GENL_NAME,
	.version        = L2TP_AC_PPPOE_GENL_VERSION,
	.hdrsize        = 0,
	.maxattr        = L2TP_AC_PPPOE_ATTR_MAX,
};

static struct nla_policy l2tp_ac_pppoe_nl_policy[L2TP_AC_PPPOE_ATTR_MAX + 1] = {
	[L2TP_AC_PPPOE_ATTR_NONE]                  = { .type = NLA_UNSPEC, },
	[L2TP_AC_PPPOE_ATTR_L2TP_TUNNEL_ID]        = { .type = NLA_U32, },
	[L2TP_AC_PPPOE_ATTR_L2TP_SESSION_ID]       = { .type = NLA_U32, },
	[L2TP_AC_PPPOE_ATTR_L2TP_PEER_SESSION_ID]  = { .type = NLA_U32, },
	[L2TP_AC_PPPOE_ATTR_PPPOE_SESSION_ID]      = { .type = NLA_U16, },
	[L2TP_AC_PPPOE_ATTR_PPPOE_IFNAME]          = {
		.type = NLA_NUL_STRING,
		.len = IFNAMSIZ - 1,
	},
};

static int l2tp_ac_pppoe_nl_cmd_noop(struct sk_buff *skb, struct genl_info *info)
{
	return 0;
}

static int l2tp_ac_pppoe_nl_cmd_add(struct sk_buff *skb, struct genl_info *info)
{
	struct net *net = genl_info_net(info);
	u32 l2tp_peer_session_id;
	u16 pppoe_session_id;
	u32 l2tp_session_id;
	u32 l2tp_tunnel_id;
	char *ifname;
	int ret;

	PRINTK(DEBUG_VERBOSE, KERN_DEBUG, "%s: enter\n", __func__);

	if (!info->attrs[L2TP_AC_PPPOE_ATTR_L2TP_TUNNEL_ID]) {
		ret = -EINVAL;
		goto out;
	}
	l2tp_tunnel_id = nla_get_u32(info->attrs[L2TP_AC_PPPOE_ATTR_L2TP_TUNNEL_ID]);
	
	if (!info->attrs[L2TP_AC_PPPOE_ATTR_L2TP_SESSION_ID]) {
		ret = -EINVAL;
		goto out;
	}
	l2tp_session_id = nla_get_u32(info->attrs[L2TP_AC_PPPOE_ATTR_L2TP_SESSION_ID]);

	if (!info->attrs[L2TP_AC_PPPOE_ATTR_L2TP_PEER_SESSION_ID]) {
		ret = -EINVAL;
		goto out;
	}
	l2tp_peer_session_id = nla_get_u32(info->attrs[L2TP_AC_PPPOE_ATTR_L2TP_PEER_SESSION_ID]);

	if (!info->attrs[L2TP_AC_PPPOE_ATTR_PPPOE_SESSION_ID]) {
		ret = -EINVAL;
		goto out;
	}
	pppoe_session_id = nla_get_u16(info->attrs[L2TP_AC_PPPOE_ATTR_PPPOE_SESSION_ID]);

	if (!info->attrs[L2TP_AC_PPPOE_ATTR_PPPOE_IFNAME]) {
		ret = -EINVAL;
		goto out;
	}
	ifname = nla_data(info->attrs[L2TP_AC_PPPOE_ATTR_PPPOE_IFNAME]);

	/* Create a new route context */
	ret = l2tp_ac_pppoe_add_route(net, pppoe_session_id, l2tp_tunnel_id,
		 	l2tp_session_id, ifname);

out:
	return ret;
}

static int l2tp_ac_pppoe_nl_cmd_del(struct sk_buff *skb, struct genl_info *info)
{
	u16 pppoe_session_id = 0;
	u32 l2tp_session_id = 0; 
	u32 l2tp_tunnel_id = 0;
	struct net *net = genl_info_net(info);
	char *ifname = NULL;
	int ret;

	PRINTK(DEBUG_VERBOSE, KERN_DEBUG, "%s: enter\n", __func__);

	if (info->attrs[L2TP_AC_PPPOE_ATTR_L2TP_TUNNEL_ID])
		l2tp_tunnel_id = nla_get_u32(info->attrs[L2TP_AC_PPPOE_ATTR_L2TP_TUNNEL_ID]);
	
	if (info->attrs[L2TP_AC_PPPOE_ATTR_L2TP_SESSION_ID])
		l2tp_session_id = nla_get_u32(info->attrs[L2TP_AC_PPPOE_ATTR_L2TP_SESSION_ID]);

	if (info->attrs[L2TP_AC_PPPOE_ATTR_PPPOE_SESSION_ID])
		pppoe_session_id = nla_get_u16(info->attrs[L2TP_AC_PPPOE_ATTR_PPPOE_SESSION_ID]);

	if (info->attrs[L2TP_AC_PPPOE_ATTR_PPPOE_IFNAME])
		ifname = nla_data(info->attrs[L2TP_AC_PPPOE_ATTR_PPPOE_IFNAME]);

	/* Try and delete the route context */
	return l2tp_ac_pppoe_del_route(net, pppoe_session_id, ifname,
		l2tp_tunnel_id, l2tp_session_id);
}

static int l2tp_ac_pppoe_nl_route_send(struct sk_buff *skb, u32 portid, u32 seq, int flags, struct l2tp_ac_pppoe_route_context *ctxt)
{
	void *hdr;

	hdr = genlmsg_put(skb, portid, seq, &l2tp_ac_pppoe_nl_family, flags,
	                  L2TP_AC_PPPOE_CMD_GET);
	if (IS_ERR(hdr))
		return PTR_ERR(hdr);
		
	if (nla_put_u32(skb, L2TP_AC_PPPOE_ATTR_L2TP_TUNNEL_ID,
		ctxt->l2tp_session->tunnel->tunnel_id) ||
	    nla_put_u32(skb, L2TP_AC_PPPOE_ATTR_L2TP_SESSION_ID,
		ctxt->l2tp_session->session_id) ||
	    nla_put_u32(skb, L2TP_AC_PPPOE_ATTR_PPPOE_SESSION_ID,
		ctxt->pppoe_session_id) ||
	    nla_put_string(skb, L2TP_AC_PPPOE_ATTR_PPPOE_IFNAME,
		ctxt->pppoe_netdev->name))
		goto nla_put_failure;

	return genlmsg_end(skb, hdr);

nla_put_failure:
	genlmsg_cancel(skb, hdr);

	return -EMSGSIZE;
}

static int l2tp_ac_pppoe_nl_cmd_get(struct sk_buff *skb, struct genl_info *info)
{
	struct l2tp_ac_pppoe_route_context *ctxt = NULL;
	bool l2tp_info = false, pppoe_info = false;
	struct net *net = genl_info_net(info);
	struct net_device *dev = NULL;
	u16 pppoe_session_id = 0;
	u32 l2tp_session_id = 0; 
	u32 l2tp_tunnel_id = 0;
	struct sk_buff *msg;
	char *ifname;
	int ret = 0;

	PRINTK(DEBUG_VERBOSE, KERN_DEBUG, "%s: enter\n", __func__);

	if (info->attrs[L2TP_AC_PPPOE_ATTR_L2TP_TUNNEL_ID] &&
	    info->attrs[L2TP_AC_PPPOE_ATTR_L2TP_SESSION_ID])
		l2tp_info = true;

	if (info->attrs[L2TP_AC_PPPOE_ATTR_PPPOE_IFNAME] &&
	    info->attrs[L2TP_AC_PPPOE_ATTR_PPPOE_SESSION_ID])
		pppoe_info = true;

	if (!(pppoe_info ^ l2tp_info)) {
		ret = -EINVAL;
		goto out;
	}

	msg = nlmsg_new(NLMSG_GOODSIZE, GFP_KERNEL);
	if (!msg) {
		ret = -ENOMEM;
		goto out;
	}

	if (pppoe_info) {
		ifname = nla_data(info->attrs[L2TP_AC_PPPOE_ATTR_PPPOE_IFNAME]);

		/* Get the struct net_device for the PPPoE interface */
		dev = dev_get_by_name(net, ifname);
		if (!dev) {
			PRINTK(DEBUG_VERBOSE, KERN_DEBUG, "%s: couldn't"
				" find struct net_device for '%s'\n",
				__func__, ifname);
			ret = -ENODEV;
			goto out;
		}

		pppoe_session_id = nla_get_u16(
			info->attrs[L2TP_AC_PPPOE_ATTR_PPPOE_SESSION_ID]);
	
		/* Find the route context */
		rcu_read_lock();
		ctxt = l2tp_ac_pppoe_get_ctxt_by_pppoe(pppoe_session_id, dev);
		dev_put(dev);
	} else {
		l2tp_tunnel_id = nla_get_u32(
			info->attrs[L2TP_AC_PPPOE_ATTR_L2TP_TUNNEL_ID]);
		l2tp_session_id = nla_get_u32(
			info->attrs[L2TP_AC_PPPOE_ATTR_L2TP_SESSION_ID]);

		/* Find the route context */
		rcu_read_lock();
		ctxt = l2tp_ac_pppoe_get_ctxt_by_l2tp(net, l2tp_tunnel_id,
		                                      l2tp_session_id);
	}

	if (!ctxt) {
		rcu_read_unlock();
		ret = -ENODEV;
		goto out;		
	}

	ret = l2tp_ac_pppoe_nl_route_send(msg, info->snd_portid, info->snd_seq,
	                                  NLM_F_ACK, ctxt);
	rcu_read_unlock();
	if (ret < 0) 
		goto err_send;

	return genlmsg_unicast(net, msg, info->snd_portid);

err_send:
	nlmsg_free(msg);

out:
	return ret;
}

static int l2tp_ac_pppoe_nl_cmd_dump(struct sk_buff *skb, struct netlink_callback *cb)
{
	struct l2tp_ac_pppoe_route_context *ctxt = NULL;
	int start = cb->args[0];
	int idx = 0;

	rcu_read_lock();
	list_for_each_entry_rcu(ctxt, &priv->ctxt_list, c_list) {
		if (++idx <= start)
			continue;
		if (!ctxt->valid)
			continue;
		if (l2tp_ac_pppoe_nl_route_send(skb, NETLINK_CB(cb->skb).portid,
			cb->nlh->nlmsg_seq, NLM_F_MULTI, ctxt) < 0) {
			idx--;
			break;
		}
	}
	rcu_read_unlock();

	cb->args[0] = idx;

	return skb->len;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,13,0)
const
#endif
static struct genl_ops l2tp_ac_pppoe_nl_ops[] = {
        {
                .cmd = L2TP_AC_PPPOE_CMD_NOOP,
                .doit = l2tp_ac_pppoe_nl_cmd_noop,
                .policy = l2tp_ac_pppoe_nl_policy,
                /* can be retrieved by unprivileged users */
        },
        {
                .cmd = L2TP_AC_PPPOE_CMD_ADD,
                .doit = l2tp_ac_pppoe_nl_cmd_add,
                .policy = l2tp_ac_pppoe_nl_policy,
                .flags = GENL_ADMIN_PERM,
        },
        {
                .cmd = L2TP_AC_PPPOE_CMD_DEL,
                .doit = l2tp_ac_pppoe_nl_cmd_del,
                .policy = l2tp_ac_pppoe_nl_policy,
                .flags = GENL_ADMIN_PERM,
        },
        {
                .cmd = L2TP_AC_PPPOE_CMD_GET,
                .doit = l2tp_ac_pppoe_nl_cmd_get,
                .dumpit = l2tp_ac_pppoe_nl_cmd_dump,
                .policy = l2tp_ac_pppoe_nl_policy,
                .flags = GENL_ADMIN_PERM,
        },
};

static const struct l2tp_nl_cmd_ops l2tp_ac_pppoe_nl_cmd_ops = {
        .session_create = l2tp_ac_pppoe_session_create,
        .session_delete = l2tp_session_delete,
};

int __init l2tp_ac_pppoe_init(void)
{
	int ret = 0, i = 0;

	if (!priv) {
		priv = kzalloc(sizeof(struct l2tp_ac_pppoe_priv),
			       GFP_KERNEL);
		if (!priv) {
			ret = -ENOMEM;
			goto error_alloc;
		}
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,13,0)
	ret = genl_register_family_with_ops(&l2tp_ac_pppoe_nl_family,
		l2tp_ac_pppoe_nl_ops);
#else
	ret = genl_register_family_with_ops(&l2tp_ac_pppoe_nl_family,
		l2tp_ac_pppoe_nl_ops, ARRAY_SIZE(l2tp_ac_pppoe_nl_ops));
#endif
	if (ret) {
		printk(KERN_ERR "Unable to register NL interface.\n");
		goto error_register;
	}

	ret = l2tp_nl_register_ops(L2TP_PWTYPE_PPP_AC, &l2tp_ac_pppoe_nl_cmd_ops);
	if (ret) {
		printk(KERN_ERR "Unable to register L2TP NL operations.\n");
		goto error_register_l2tp;
	}

	/* Init PPPoE hash list */
	for (i = 0; i < PPPOE_SES_HASH_SIZE; i++) {
		INIT_HLIST_HEAD(&priv->pppoe_hlist[i]);
	}

	spin_lock_init(&priv->list_lock);
	INIT_LIST_HEAD(&priv->ctxt_list);

	dev_add_pack(&pppoes_ptype);

	printk(KERN_INFO "L2TP PPPoE Access Concentrator driver, "
		L2TP_AC_PPPOE_DRV_VERSION "\n");

	return 0;
		
error_register_l2tp:
	genl_unregister_family(&l2tp_ac_pppoe_nl_family);
error_register:
	kfree(priv);
error_alloc:
	return ret;
}

void __exit l2tp_ac_pppoe_exit(void)
{
	if (priv) {
		dev_remove_pack(&pppoes_ptype);
		l2tp_nl_unregister_ops(L2TP_PWTYPE_PPP_AC);
		genl_unregister_family(&l2tp_ac_pppoe_nl_family);
		kfree(priv);
	}
}

module_init(l2tp_ac_pppoe_init);
module_exit(l2tp_ac_pppoe_exit);

MODULE_AUTHOR("Chris Elston <celston@katalix.com>");
MODULE_DESCRIPTION("L2TP PPPoE Access Concentrator");
MODULE_LICENSE("GPL");
MODULE_VERSION(L2TP_AC_PPPOE_DRV_VERSION);
