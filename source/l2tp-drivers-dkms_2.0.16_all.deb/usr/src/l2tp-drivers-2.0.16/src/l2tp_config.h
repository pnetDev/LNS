#ifndef _L2TP_CONFIG_H_
#define _L2TP_CONFIG_H_

#undef __enabled_CONFIG_L2TP_DEBUGFS
#undef __enabled_CONFIG_L2TP_DEBUGFS_MODULE
#undef CONFIG_L2TP_DEBUGFS_MODULE
#undef __enabled_CONFIG_L2TP_IP
#undef __enabled_CONFIG_L2TP_IP_MODULE
#undef CONFIG_L2TP_IP_MODULE
#undef __enabled_CONFIG_L2TP_ETH
#undef __enabled_CONFIG_L2TP_ETH_MODULE
#undef CONFIG_L2TP_ETH_MODULE
#undef __enabled_CONFIG_L2TP
#undef __enabled_CONFIG_L2TP_MODULE
#undef CONFIG_L2TP_MODULE
#undef __enabled_CONFIG_PPPOL2TP
#undef __enabled_CONFIG_PPPOL2TP_MODULE
#undef CONFIG_PPPOL2TP_MODULE
#undef __enabled_CONFIG_L2TP_V3
#undef __enabled_CONFIG_L2TP_V3_MODULE
#undef CONFIG_L2TP_V3

#define __enabled_CONFIG_L2TP_DEBUGFS 0
#define __enabled_CONFIG_L2TP_DEBUGFS_MODULE 1
#define CONFIG_L2TP_DEBUGFS_MODULE 1
#define __enabled_CONFIG_L2TP_IP 0
#define __enabled_CONFIG_L2TP_IP_MODULE 1
#define CONFIG_L2TP_IP_MODULE 1
#define __enabled_CONFIG_L2TP_ETH 0
#define __enabled_CONFIG_L2TP_ETH_MODULE 1
#define CONFIG_L2TP_ETH_MODULE 1
#define __enabled_CONFIG_L2TP 0
#define __enabled_CONFIG_L2TP_MODULE 1
#define CONFIG_L2TP_MODULE 1
#define __enabled_CONFIG_PPPOL2TP 0
#define __enabled_CONFIG_PPPOL2TP_MODULE 1
#define CONFIG_PPPOL2TP_MODULE 1
#define __enabled_CONFIG_L2TP_V3 1
#define __enabled_CONFIG_L2TP_V3_MODULE 0
#define CONFIG_L2TP_V3 1

#endif
