/*
 * L2TP compat definitions.
 *
 * Copyright (c) 2012 Katalix Systems Ltd
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 */

#ifndef _L2TP_COMPAT_H_
#define _L2TP_COMPAT_H_

#include <linux/version.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,33)
#include <linux/autoconf.h>
#else
#include <generated/autoconf.h>
#endif
#include <linux/types.h>
#include <net/netlink.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(3,5,0)
#include <linux/netlink.h>
/**
 * nla_put_be32 - Add a __be32 netlink attribute to a socket buffer
 * @skb: socket buffer to add attribute to
 * @attrtype: attribute type
 * @value: numeric value
 */
static inline int nla_put_be32(struct sk_buff *skb, int attrtype, __be32 value)
{
	return nla_put(skb, attrtype, sizeof(__be32), &value);
}
#endif /* KERNEL_VERSION < 3.5.0 */

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,36)
#include <linux/etherdevice.h>
#define eth_hw_addr_random(dev) do { \
       random_ether_addr(dev->dev_addr); \
} while(0)
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,4,0)
#include <linux/etherdevice.h>
#define eth_hw_addr_random(dev) do { \
       dev->addr_assign_type |= NET_ADDR_RANDOM; \
       random_ether_addr(dev->dev_addr); \
} while(0)
#endif /* KERNEL_VERSION < 3.4.0 */
#endif /* KERNEL_VERSION < 2.6.36 */

#if LINUX_VERSION_CODE < KERNEL_VERSION(3,5,0)
#ifdef L2TP_EXTERNAL
#ifdef __KERNEL__
#include <linux/in.h>
#include <linux/in6.h>
#endif
#include <linux/socket.h>
#include <linux/if_pppol2tp.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(3,1,0)
typedef unsigned short  __kernel_sa_family_t;
#endif

/* Structure used to connect() the socket to a particular tunnel UDP
 * socket over IPv6.
 */
struct pppol2tpin6_addr {
	__kernel_pid_t	pid;		/* pid that owns the fd.
					 * 0 => current */
	int	fd;			/* FD of UDP socket to use */

	__u16 s_tunnel, s_session;	/* For matching incoming packets */
	__u16 d_tunnel, d_session;	/* For sending outgoing packets */

	struct sockaddr_in6 addr;	/* IP address and port to send to */
};

struct pppol2tpv3in6_addr {
	__kernel_pid_t	pid;		/* pid that owns the fd.
					 * 0 => current */
	int	fd;			/* FD of UDP or IP socket to use */

	__u32 s_tunnel, s_session;	/* For matching incoming packets */
	__u32 d_tunnel, d_session;	/* For sending outgoing packets */

	struct sockaddr_in6 addr;	/* IP address and port to send to */
};

struct sockaddr_pppol2tpin6 {
	__kernel_sa_family_t sa_family; /* address family, AF_PPPOX */
	unsigned int    sa_protocol;    /* protocol identifier */
	struct pppol2tpin6_addr pppol2tp;
} __packed;

struct sockaddr_pppol2tpv3in6 {
	__kernel_sa_family_t sa_family; /* address family, AF_PPPOX */
	unsigned int    sa_protocol;    /* protocol identifier */
	struct pppol2tpv3in6_addr pppol2tp;
} __packed;

/**
 * struct sockaddr_l2tpip6 - the sockaddr structure for L2TP-over-IPv6 sockets
 * @l2tp_family:  address family number AF_L2TPIP.
 * @l2tp_addr:    protocol specific address information
 * @l2tp_conn_id: connection id of tunnel
 */
struct sockaddr_l2tpip6 {
	/* The first fields must match struct sockaddr_in6 */
	__kernel_sa_family_t l2tp_family; /* AF_INET6 */
	__be16		l2tp_unused;	/* INET port number (unused) */
	__be32		l2tp_flowinfo;	/* IPv6 flow information */
	struct in6_addr	l2tp_addr;	/* IPv6 address */
	__u32		l2tp_scope_id;	/* scope id (new in RFC2553) */
	__u32		l2tp_conn_id;	/* Connection ID of tunnel */
};

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,35)
enum {
	L2TP_ATTR_IP6_SADDR = 31,	/* struct in6_addr */
	L2TP_ATTR_IP6_DADDR = 32,	/* struct in6_addr */
};
#undef L2TP_ATTR_MAX
#define L2TP_ATTR_MAX 32
#endif
#endif /* L2TP_EXTERNAL */

static inline void udp_encap_enable(void)
{
}

static inline void udpv6_encap_enable(void)
{
}

#endif /* KERNEL_VERSION < 3.5.0 */

#if LINUX_VERSION_CODE < KERNEL_VERSION(3,1,0)
#define datagram_send_ctl(_net, _sk, _msg, _fl6, _opt, _hlimit, _tclass, _dontfrag) \
	datagram_send_ctl_1((_net), (_msg), (_fl6), (_opt), (_hlimit), (_tclass), (_dontfrag))
#define datagram_send_ctl_1 datagram_send_ctl
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,9,0)
#define hlist_for_each_entry_compat(x, tmp, obj, member) \
	hlist_for_each_entry(x, obj, member)
#define hlist_for_each_entry_rcu_compat(x, tmp, obj, member) \
	hlist_for_each_entry_rcu(x, obj, member)
#define sk_for_each_bound_compat(x, tmp, lst) \
	sk_for_each_bound(x, lst)
#else
#define hlist_for_each_entry_compat(x, tmp, obj, member) \
	hlist_for_each_entry(x, tmp, obj, member)
#define hlist_for_each_entry_rcu_compat(x, tmp, obj, member) \
	hlist_for_each_entry_rcu(x, tmp, obj, member)
#define sk_for_each_bound_compat(x, tmp, lst) \
	sk_for_each_bound(x, tmp, lst)
#endif

#if LINUX_VERSION_CODE <= KERNEL_VERSION(3,7,0)
#define ip6_datagram_send_ctl(_net, _sk, _msg, _fl6, _opt, _hlimit, _tclass, _dontfrag) \
	datagram_send_ctl(_net, _sk, _msg, _fl6, _opt, _hlimit, _tclass, _dontfrag)
#define ip6_datagram_recv_ctl(_sk, _msg, _skb) \
	datagram_recv_ctl(_sk, _msg, _skb)
#endif

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,32)
#define inet_daddr	   daddr
#define inet_saddr	   saddr
#define inet_dport     dport
#define inet_sport     sport
#define inet_rcv_saddr rcv_saddr
#define inet_num       num
#define inet_id        id
#endif

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,35)
#define pr_emerg(fmt, ...) \
        printk(KERN_EMERG pr_fmt(fmt), ##__VA_ARGS__)
#define pr_alert(fmt, ...) \
        printk(KERN_ALERT pr_fmt(fmt), ##__VA_ARGS__)
#define pr_crit(fmt, ...) \
        printk(KERN_CRIT pr_fmt(fmt), ##__VA_ARGS__)
#define pr_err(fmt, ...) \
        printk(KERN_ERR pr_fmt(fmt), ##__VA_ARGS__)
#define pr_warning(fmt, ...) \
        printk(KERN_WARNING pr_fmt(fmt), ##__VA_ARGS__)
#define pr_warn pr_warning
#define pr_notice(fmt, ...) \
        printk(KERN_NOTICE pr_fmt(fmt), ##__VA_ARGS__)
#define pr_info(fmt, ...) \
        printk(KERN_INFO pr_fmt(fmt), ##__VA_ARGS__)
#define pr_cont(fmt, ...) \
        printk(KERN_CONT fmt, ##__VA_ARGS__)
#endif

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,34)
/* The L2TPv3 protocol changes tunnel and session ids from 16 to 32
 * bits. So we need a different sockaddr structure.
 */
struct pppol2tpv3_addr {
	pid_t   pid;                    /* pid that owns the fd.
	                                 * 0 => current */
	int     fd;                     /* FD of UDP or IP socket to use */

	struct sockaddr_in addr;        /* IP address and port to send to */

	__u32 s_tunnel, s_session;      /* For matching incoming packets */
	__u32 d_tunnel, d_session;      /* For sending outgoing packets */
};

/* The L2TPv3 protocol changes tunnel and session ids from 16 to 32
 * bits. So we need a different sockaddr structure.
 */
struct sockaddr_pppol2tpv3 {
	sa_family_t     sa_family;      /* address family, AF_PPPOX */
	unsigned int    sa_protocol;    /* protocol identifier */
	struct pppol2tpv3_addr pppol2tp;
} __attribute__ ((packed));
#endif

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,32)
#include <linux/skbuff.h>
#include <net/xfrm.h>

static inline int dev_forward_skb(struct net_device *dev, struct sk_buff *skb)
{
	skb_orphan(skb);

	if (!(dev->flags & IFF_UP))
		return NET_RX_DROP;

	if (skb->len > (dev->mtu + dev->hard_header_len))
		return NET_RX_DROP;

	skb_dst_drop(skb);
	skb->tstamp.tv64 = 0;
	skb->pkt_type = PACKET_HOST;
	skb->protocol = eth_type_trans(skb, dev);
	skb->mark = 0;
	secpath_reset(skb);
	nf_reset(skb);
	return netif_rx(skb);
}
#endif

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,34)
#define inet6_csk_xmit(skb, flowi) inet6_csk_xmit(skb, 0)
#elif LINUX_VERSION_CODE < KERNEL_VERSION(3,0,0)
#define inet6_csk_xmit(skb, flowi) inet6_csk_xmit(skb)
#endif

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,34)
#define ip_queue_xmit(skb, flowi) ip_queue_xmit(skb, 0)
#elif LINUX_VERSION_CODE < KERNEL_VERSION(3,0,0)
#define ip_queue_xmit(skb, flowi) ip_queue_xmit(skb)
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,15,0)
#define WQ_NON_REENTRANT 0
#endif

#endif /* _L2TP_COMPAT_H_ */
